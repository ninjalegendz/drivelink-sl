/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { 
  ShieldCheck, 
  CheckCircle, 
  AlertCircle, 
  X, 
  Award, 
  MapPin, 
  User, 
  TrendingUp, 
  FileText, 
  Smartphone,
  CheckCircle2,
  Lock,
  Compass
} from 'lucide-react';
import { Vehicle, BookingRequest } from '../types';

interface AdminPortalProps {
  vehicles: Vehicle[];
  bookings: BookingRequest[];
  onApproveVehicle: (vehicleId: string) => void;
  onVerifyBooking: (bookingId: string) => void;
  onRejectVehicle: (vehicleId: string) => void;
}

export default function AdminPortal({
  vehicles,
  bookings,
  onApproveVehicle,
  onVerifyBooking,
  onRejectVehicle
}: AdminPortalProps) {

  // Newly listed vehicles that are pending approval
  const pendingVehicles = useMemo(() => {
    return vehicles.filter(v => !v.isApproved);
  }, [vehicles]);

  // Bookings that are pending admin license checks
  const pendingBookings = useMemo(() => {
    return bookings.filter(b => b.status === 'pending');
  }, [bookings]);

  return (
    <div className="space-y-8">
      {/* Platform Ledger Metrics */}
      <div className="bg-slate-950 text-white rounded-xl p-6 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-blue-400 tracking-wider uppercase mb-1">
            <Lock className="w-3 h-3" /> DriveLink secure admin board
          </div>
          <h2 className="text-xl font-black tracking-tight text-white">Trust Engine & Verification Ledger</h2>
          <p className="text-xs text-slate-400 max-w-lg">
            Reviewing owner vehicle documents and verifying international tourist driver licenses to build Sri Lanka's safest rental network.
          </p>
        </div>

        {/* Quick Admin Stats */}
        <div className="flex gap-4 flex-wrap">
          <div className="bg-slate-900 border border-slate-800 px-4 py-2.5 rounded-lg space-y-0.5">
            <span className="text-[10px] text-slate-500 font-bold uppercase">Pending Listings</span>
            <p className="text-lg font-black text-amber-400">{pendingVehicles.length}</p>
          </div>
          <div className="bg-slate-900 border border-slate-800 px-4 py-2.5 rounded-lg space-y-0.5">
            <span className="text-[10px] text-slate-500 font-bold uppercase">Active Inquiries</span>
            <p className="text-lg font-black text-blue-400">{pendingBookings.length}</p>
          </div>
          <div className="bg-slate-900 border border-slate-800 px-4 py-2.5 rounded-lg space-y-0.5">
            <span className="text-[10px] text-slate-500 font-bold uppercase">Live Fleet Size</span>
            <p className="text-lg font-black text-blue-400">
              {vehicles.filter(v => v.isApproved).length} verified
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Moderate Vehicle Listings */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-800 text-base flex items-center gap-2">
              <Compass className="w-5 h-5 text-blue-600" /> Vehicle Moderation Queue ({pendingVehicles.length})
            </h3>
            <span className="text-xs text-slate-400 font-medium">Verify registration book (CR)</span>
          </div>

          {pendingVehicles.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-slate-100 rounded-xl text-slate-400 text-xs italic">
              All listed vehicle registrations have been moderated and are active live.
            </div>
          ) : (
            <div className="space-y-4">
              {pendingVehicles.map((v) => (
                <div key={v.id} className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm flex flex-col md:flex-row">
                  {/* Photo column */}
                  <div className="md:w-36 bg-slate-100 relative aspect-video md:aspect-auto">
                    <img src={v.image} alt={v.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded font-bold border border-amber-100 uppercase tracking-wider">
                          Pending Approval
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">Host: {v.ownerName}</span>
                      </div>
                      <h4 className="font-bold text-slate-800 text-sm mt-1">{v.title}</h4>
                      
                      <div className="text-[10px] text-slate-400 mt-1 space-y-0.5">
                        <p>Location: <span className="font-semibold text-slate-600">{v.location}</span></p>
                        <p>Rates: <span className="font-semibold text-blue-700">${v.pricePerDayUSD}/day</span> (~LKR {v.pricePerDayLKR.toLocaleString()})</p>
                        <p>Specs: <span className="font-semibold text-slate-600">{v.transmission} • {v.fuelType} • {v.seats} seats</span></p>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 border-t border-slate-50 pt-2.5">
                      <button
                        id={`btn-admin-reject-vehicle-${v.id}`}
                        onClick={() => onRejectVehicle(v.id)}
                        className="px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                      >
                        Decline
                      </button>
                      <button
                        id={`btn-admin-approve-vehicle-${v.id}`}
                        onClick={() => onApproveVehicle(v.id)}
                        className="px-4 py-1.5 text-xs font-black bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-sm flex items-center gap-1"
                      >
                        <CheckCircle className="w-3.5 h-3.5" /> Approve & Tag
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Customer Document & License Verification Queue */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-800 text-base flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-600" /> License & Identity Checks Queue ({pendingBookings.length})
            </h3>
            <span className="text-xs text-slate-400 font-medium">Verify tourist driving permits</span>
          </div>

          {pendingBookings.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-slate-100 rounded-xl text-slate-400 text-xs italic">
              All tourist license check requests are verified. Handshakes dispatched to hosts.
            </div>
          ) : (
            <div className="space-y-4">
              {pendingBookings.map((b) => (
                <div key={b.id} className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm space-y-4">
                  <div className="flex justify-between items-start border-b border-slate-100 pb-2">
                    <div>
                      <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Inquiry {b.id}</span>
                      <h4 className="font-bold text-slate-800 text-xs">{b.vehicleTitle}</h4>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 bg-slate-50 px-2 py-0.5 rounded border">
                      {b.totalDays} Days (${b.totalPrice})
                    </span>
                  </div>

                  {/* Customer details verification display */}
                  <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <div>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Customer Details</p>
                      <p className="font-bold text-slate-700 mt-0.5">{b.customerName}</p>
                      <p className="text-[10px] text-slate-500">{b.customerCountry}</p>
                    </div>
                    <div>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Inquiry Options</p>
                      <p className="font-bold text-slate-700 capitalize mt-0.5">{b.rentalType}</p>
                      <p className="text-[10px] text-slate-500">Route: {b.pickupLocation} → {b.returnLocation}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[10px] text-amber-600 font-bold flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 animate-pulse" /> Awaiting license endorsement confirm
                    </span>
                    
                    <button
                      id={`btn-admin-verify-booking-${b.id}`}
                      onClick={() => onVerifyBooking(b.id)}
                      className="px-4 py-1.5 text-xs font-black bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-sm flex items-center gap-1"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" /> Approve License & Dispatch
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
