/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Car, 
  MapPin, 
  FileText, 
  Upload, 
  CheckCircle, 
  AlertCircle, 
  ShieldCheck, 
  Eye, 
  Trash2, 
  DollarSign, 
  TrendingUp, 
  Calendar,
  X,
  Smartphone,
  Sparkles,
  Award
} from 'lucide-react';
import { Vehicle, BookingRequest, Owner } from '../types';
import { VEHICLE_TYPES, LOCATIONS, SAMPLE_OWNER } from '../data';

interface OwnerPortalProps {
  vehicles: Vehicle[];
  bookings: BookingRequest[];
  onAddVehicle: (newVehicle: Vehicle) => void;
  onUpdateBookingStatus: (bookingId: string, status: BookingRequest['status']) => void;
  onDeleteVehicle: (vehicleId: string) => void;
}

export default function OwnerPortal({
  vehicles,
  bookings,
  onAddVehicle,
  onUpdateBookingStatus,
  onDeleteVehicle
}: OwnerPortalProps) {
  // Current owner logged in (Sample)
  const [owner, setOwner] = useState<Owner>(SAMPLE_OWNER);
  
  // Tab state inside Owner View: "Listings" vs "Booking Requests" vs "Verification & Profile"
  const [activeTab, setActiveTab] = useState<'listings' | 'requests' | 'verification'>('listings');

  // Form State for Adding New Vehicle Listing
  const [showAddModal, setShowAddModal] = useState(false);
  const [newVehicleData, setNewVehicleData] = useState({
    title: '',
    type: 'car' as Vehicle['type'],
    brand: '',
    model: '',
    year: 2022,
    image: '',
    pricePerDayLKR: 6000,
    pricePerDayUSD: 20,
    transmission: 'automatic' as Vehicle['transmission'],
    fuelType: 'petrol' as Vehicle['fuelType'],
    seats: 5,
    luggage: 2,
    location: 'Negombo',
    isSelfDrive: true,
    isWithDriver: false,
    isAirportPickup: false,
    depositLKR: 15000,
    depositUSD: 50,
    mileageLimit: '120 km/day',
    extraMileageCharge: 40,
    rules: 'No smoking; International License; Keep clean'
  });

  // Simulated Document Upload State
  const [documentFiles, setDocumentFiles] = useState<{
    nic?: string;
    registration?: string;
    insurance?: string;
  }>({});
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Filter listings owned by this current sample host
  const myVehicles = useMemo(() => {
    return vehicles.filter(v => v.ownerId === owner.id);
  }, [vehicles, owner.id]);

  // Filter bookings received for this owner's listings
  const receivedBookings = useMemo(() => {
    // Collect ids of vehicles owned by current owner
    const myVehicleIds = myVehicles.map(v => v.id);
    return bookings.filter(b => myVehicleIds.includes(b.vehicleId));
  }, [bookings, myVehicles]);

  // Handle submit new vehicle form
  const handleCreateVehicle = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Some random premium-looking Unsplash car images if none provided
    let finalImg = newVehicleData.image;
    if (!finalImg) {
      if (newVehicleData.type === 'car') {
        finalImg = 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=800';
      } else if (newVehicleData.type === 'suv') {
        finalImg = 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=800';
      } else if (newVehicleData.type === 'van') {
        finalImg = 'https://images.unsplash.com/photo-1527786356703-4b100091cd2c?auto=format&fit=crop&q=80&w=800';
      } else if (newVehicleData.type === 'bike') {
        finalImg = 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&q=80&w=800';
      } else {
        finalImg = 'https://images.unsplash.com/photo-1566371486490-560ded239ff6?auto=format&fit=crop&q=80&w=800';
      }
    }

    const created: Vehicle = {
      id: `v_user_${Date.now().toString().slice(-4)}`,
      title: newVehicleData.title,
      type: newVehicleData.type,
      brand: newVehicleData.brand,
      model: newVehicleData.model,
      year: Number(newVehicleData.year),
      image: finalImg,
      pricePerDayLKR: Number(newVehicleData.pricePerDayLKR),
      pricePerDayUSD: Number(newVehicleData.pricePerDayUSD),
      transmission: newVehicleData.transmission,
      fuelType: newVehicleData.fuelType,
      seats: Number(newVehicleData.seats),
      luggage: Number(newVehicleData.luggage),
      location: newVehicleData.location,
      isSelfDrive: newVehicleData.isSelfDrive,
      isWithDriver: newVehicleData.isWithDriver,
      isAirportPickup: newVehicleData.isAirportPickup,
      depositLKR: Number(newVehicleData.depositLKR),
      depositUSD: Number(newVehicleData.depositUSD),
      mileageLimit: newVehicleData.mileageLimit,
      extraMileageCharge: Number(newVehicleData.extraMileageCharge),
      rules: newVehicleData.rules.split(';').map(r => r.trim()).filter(Boolean),
      ownerId: owner.id,
      ownerName: owner.name,
      ownerPhone: owner.phone,
      ownerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      ownerRating: 5.0,
      ownerResponseTime: 'under 10 mins',
      badges: ['Verified Owner', 'Self-Drive Available', 'Fast Response'],
      reviewsCount: 0,
      isApproved: false, // Must be approved by Admin in Admin view! (Prompts great interactive workflow)
      documentStatus: 'pending'
    };

    onAddVehicle(created);
    setShowAddModal(false);
    
    // Reset form
    setNewVehicleData({
      title: '',
      type: 'car',
      brand: '',
      model: '',
      year: 2022,
      image: '',
      pricePerDayLKR: 6000,
      pricePerDayUSD: 20,
      transmission: 'automatic',
      fuelType: 'petrol',
      seats: 5,
      luggage: 2,
      location: 'Negombo',
      isSelfDrive: true,
      isWithDriver: false,
      isAirportPickup: false,
      depositLKR: 15000,
      depositUSD: 50,
      mileageLimit: '120 km/day',
      extraMileageCharge: 40,
      rules: 'No smoking; International License; Keep clean'
    });
  };

  // Simulated verification submit
  const handleVerifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitSuccess(true);
    setTimeout(() => {
      setOwner(prev => ({ ...prev, isVerified: true }));
      setSubmitSuccess(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Launch Promo Ribbon */}
      <div className="bg-blue-600 text-white px-6 py-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm border border-blue-500">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1.5 font-extrabold text-xs tracking-wider uppercase bg-white/15 text-white px-2 py-0.5 rounded-full w-fit">
            <Sparkles className="w-3.5 h-3.5" /> FREE-LAUNCH SPECIAL PROMO
          </div>
          <h3 className="font-extrabold text-sm md:text-base tracking-tight text-white">
            0% Commission Fee & Free Verifications for Early Partners!
          </h3>
          <p className="text-[11px] text-blue-100 leading-normal">
            No listing fees, no subscription cards, and zero dispute escrows during our beta launch. You receive bookings directly!
          </p>
        </div>
        <button
          id="btn-owner-create-listing"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-extrabold bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors shadow-md"
        >
          <Plus className="w-4 h-4" /> Add Free Listing
        </button>
      </div>

      {/* Host Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm space-y-1">
          <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Total Listings</p>
          <div className="flex items-baseline justify-between">
            <h4 className="text-2xl font-black text-slate-800">{myVehicles.length}</h4>
            <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-1.5 py-0.5 rounded">All Free</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm space-y-1">
          <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Total Inquiries Received</p>
          <div className="flex items-baseline justify-between">
            <h4 className="text-2xl font-black text-slate-800">{receivedBookings.length}</h4>
            <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-1.5 py-0.5 rounded">
              {receivedBookings.filter(b => b.status === 'pending').length} pending
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm space-y-1">
          <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Completed Rentals</p>
          <div className="flex items-baseline justify-between">
            <h4 className="text-2xl font-black text-slate-800">{owner.completedBookings}</h4>
            <div className="flex items-center gap-0.5 text-xs text-amber-500 font-bold">
              ★ 4.9
            </div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm space-y-1">
          <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Launch Revenue Generated</p>
          <div className="flex items-baseline justify-between">
            <h4 className="text-2xl font-black text-blue-700">
              ${receivedBookings.filter(b => b.status === 'approved_by_owner' || b.status === 'completed').reduce((sum, b) => sum + b.totalPrice, 0)}
            </h4>
            <span className="text-[10px] text-slate-400 font-medium">USD</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-100 flex gap-4">
        <button
          id="tab-owner-listings"
          onClick={() => setActiveTab('listings')}
          className={`py-2 text-sm font-bold border-b-2 transition-all ${
              activeTab === 'listings' 
                ? 'border-blue-600 text-slate-800' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            My Vehicles ({myVehicles.length})
          </button>
          <button
            id="tab-owner-requests"
            onClick={() => setActiveTab('requests')}
            className={`py-2 text-sm font-bold border-b-2 relative transition-all ${
              activeTab === 'requests' 
                ? 'border-blue-600 text-slate-800' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Inquiries / Bookings ({receivedBookings.length})
            {receivedBookings.filter(b => b.status === 'pending').length > 0 && (
              <span className="absolute top-1 -right-4 h-4 w-4 bg-amber-500 text-[9px] text-white rounded-full flex items-center justify-center font-bold">
                {receivedBookings.filter(b => b.status === 'pending').length}
              </span>
            )}
          </button>
          <button
            id="tab-owner-verification"
            onClick={() => setActiveTab('verification')}
            className={`py-2 text-sm font-bold border-b-2 transition-all ${
              activeTab === 'verification' 
                ? 'border-blue-600 text-slate-800' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Host Documents Verification
            {owner.isVerified ? (
              <span className="ml-1.5 inline-block text-[10px] bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-extrabold border border-blue-100">
                ✓ Verified
              </span>
          ) : (
            <span className="ml-1.5 inline-block text-[10px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded font-extrabold border border-amber-200">
              ! Check Pending
            </span>
          )}
        </button>
      </div>

      {/* Render Listings Section */}
      {activeTab === 'listings' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 text-base">Listed Vehicles</h3>
          </div>

          {myVehicles.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-100 space-y-4">
              <div className="h-12 w-12 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                <Car className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-semibold text-slate-700">You have no listed vehicles yet</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto mt-0.5">List your cars, bikes, vans or tuk-tuks for free today to start getting premium foreign bookings.</p>
              </div>
              <button
                id="btn-owner-first-listing"
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-lg transition-colors"
              >
                Create Your First Listing
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myVehicles.map((v) => (
                <div key={v.id} className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="relative aspect-video bg-slate-100">
                      <img src={v.image} alt={v.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <span className={`absolute top-3 left-3 px-2.5 py-1 text-[10px] font-extrabold rounded backdrop-blur-md text-white ${
                        v.isApproved 
                          ? 'bg-blue-600/90' 
                          : 'bg-amber-600/95 border border-amber-500/20 shadow-sm animate-pulse'
                      }`}>
                        {v.isApproved ? '✓ Active Live' : '◷ Pending Admin Review'}
                      </span>
                    </div>

                    <div className="p-4 space-y-2">
                      <h4 className="font-bold text-slate-800 leading-tight line-clamp-1">{v.title}</h4>
                      
                      <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
                        <span>{v.location}</span>
                        <span>{v.transmission} • {v.fuelType}</span>
                      </div>

                      <div className="flex flex-wrap gap-1 pt-1">
                        {v.badges.map(b => (
                          <span key={b} className="text-[9px] bg-slate-50 text-slate-600 px-1.5 py-0.5 rounded font-bold border border-slate-100">
                            {b}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/50">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block">Rate Set</span>
                      <span className="text-sm font-extrabold text-slate-800">${v.pricePerDayUSD}/day</span>
                    </div>
                    <button
                      id={`btn-owner-delete-vehicle-${v.id}`}
                      onClick={() => onDeleteVehicle(v.id)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 hover:text-rose-600 rounded-lg transition-colors"
                      title="Remove listing"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Render Booking Requests Section */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          <h3 className="font-bold text-slate-800 text-base">Inbound Customer Inquiries</h3>

          {receivedBookings.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-100 text-slate-400 italic text-xs">
              No reservation inquiries received for your listings yet. High season tourist demand spikes on weekends.
            </div>
          ) : (
            <div className="space-y-4">
              {receivedBookings.map((b) => {
                const isPending = b.status === 'pending';
                const isVerified = b.status === 'verified';
                const isApprovedByOwner = b.status === 'approved_by_owner';
                const isCompleted = b.status === 'completed';

                return (
                  <div key={b.id} className="bg-white rounded-xl border border-slate-100 p-6 shadow-sm space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold tracking-wider uppercase">Inquiry ID: {b.id}</span>
                        <h4 className="font-bold text-slate-800 text-sm mt-0.5">{b.vehicleTitle}</h4>
                      </div>

                      {/* Display Status */}
                      <div>
                        {isPending && (
                          <span className="text-xs bg-amber-50 text-amber-700 px-2.5 py-1 rounded-full border border-amber-200 font-bold">
                            ◷ Pending License Checks
                          </span>
                        )}
                        {isVerified && (
                          <span className="text-xs bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full border border-blue-200 font-bold">
                            ✓ License Verified by Admin
                          </span>
                        )}
                        {isApprovedByOwner && (
                          <span className="text-xs bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full border border-blue-200 font-bold">
                            ✓ Accepted by You
                          </span>
                        )}
                        {isCompleted && (
                          <span className="text-xs bg-slate-50 text-slate-600 px-2.5 py-1 rounded-full border border-slate-200 font-bold">
                            ✓ Completed
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {/* Customer Profile info */}
                      <div className="space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-100">
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Customer Details</p>
                        <p className="text-xs font-bold text-slate-800">{b.customerName}</p>
                        <p className="text-[10px] text-slate-500 font-semibold">{b.customerCountry}</p>
                        <p className="text-[10px] text-slate-400">{b.customerEmail}</p>
                      </div>

                      {/* Dates / Terms */}
                      <div className="space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-100">
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Dates & Type</p>
                        <p className="text-xs font-bold text-slate-800">{b.startDate} to {b.endDate}</p>
                        <p className="text-[10px] text-slate-500 font-semibold">{b.totalDays} Days • {b.rentalType}</p>
                        <p className="text-[10px] text-slate-400">Route: {b.pickupLocation} → {b.returnLocation}</p>
                      </div>

                      {/* Financial payout representation */}
                      <div className="space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-100 flex flex-col justify-between">
                        <div>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Launch Payout (0% fee)</p>
                          <p className="text-sm font-extrabold text-blue-800">${b.totalPrice} USD</p>
                        </div>
                        <p className="text-[9px] text-blue-600 font-bold">✓ Full payment directly from customer upon handover.</p>
                      </div>
                    </div>

                    {/* Booking message */}
                    {b.notes && (
                      <div className="text-xs text-slate-500 italic bg-slate-50/50 p-3 rounded border border-slate-100">
                        "{b.notes}"
                      </div>
                    )}

                    {/* Interaction Buttons */}
                    <div className="flex justify-end gap-2 border-t border-slate-100 pt-3">
                      {isPending && (
                        <p className="text-xs text-amber-600 font-semibold flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 animate-pulse" /> Awaiting DriveLink administrator's license and security checks...
                        </p>
                      )}
                      
                      {isVerified && (
                        <>
                          <button
                            id={`btn-owner-decline-booking-${b.id}`}
                            onClick={() => onUpdateBookingStatus(b.id, 'rejected')}
                            className="px-3.5 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                          >
                            Decline Inquiry
                          </button>
                          <button
                            id={`btn-owner-accept-booking-${b.id}`}
                            onClick={() => onUpdateBookingStatus(b.id, 'approved_by_owner')}
                            className="px-4 py-1.5 text-xs font-extrabold bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-sm"
                          >
                            Accept Booking Request
                          </button>
                        </>
                      )}

                      {isApprovedByOwner && (
                        <div className="flex items-center gap-3">
                          <span className="text-xs text-blue-700 font-bold flex items-center gap-1">
                            <CheckCircle className="w-4 h-4" /> Active Booking Coordination Unlocked!
                          </span>
                          <a
                            href={`https://wa.me/${b.customerPhone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3.5 py-1.5 text-xs font-extrabold bg-blue-600 hover:bg-blue-500 text-white rounded-lg flex items-center gap-1.5"
                          >
                            <Smartphone className="w-3.5 h-3.5" /> WhatsApp Guest
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Render Verification Center Tab */}
      {activeTab === 'verification' && (
        <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-sm space-y-6">
          <div className="space-y-1">
            <h3 className="font-bold text-slate-800 text-lg">Verification Badge Center</h3>
            <p className="text-xs text-slate-400">Verified hosts get 3.8x more booking clicks. Submit simple proofs to stand out.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4 border border-slate-100 rounded-xl p-4 bg-slate-50/50">
              <div className="h-8 w-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 font-bold">
                ✓
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  Verified Owner Badge <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Assigned instantly upon national identity check or registered driver permit.</p>
              </div>
            </div>

            <div className="space-y-4 border border-slate-100 rounded-xl p-4 bg-slate-50/50">
              <div className="h-8 w-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 font-bold">
                ✓
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  Documents Checked Badge <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Assigned when vehicle registration book (CR) and commercial insurance are validated.</p>
              </div>
            </div>

            <div className="space-y-4 border border-slate-100 rounded-xl p-4 bg-slate-50/50">
              <div className="h-8 w-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 font-bold">
                ✓
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  Tourist Friendly Badge <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Assigned for English proficiency, clear refundable deposit rules, and licensing endorsements.</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleVerifySubmit} className="space-y-4 border-t border-slate-100 pt-6">
            <h4 className="font-bold text-slate-800 text-sm">Submit New Registration Documents</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-500 font-semibold uppercase">National NIC or Driver License Copy</label>
                <div className="border border-dashed border-slate-200 rounded-lg p-4 text-center cursor-pointer hover:bg-slate-50 transition-colors">
                  <Upload className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                  <p className="text-[10px] font-bold text-slate-600">Click to upload doc</p>
                  <p className="text-[9px] text-slate-400">PDF, JPG up to 5MB</p>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-500 font-semibold uppercase">Vehicle Registration Certificate (CR)</label>
                <div className="border border-dashed border-slate-200 rounded-lg p-4 text-center cursor-pointer hover:bg-slate-50 transition-colors">
                  <Upload className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                  <p className="text-[10px] font-bold text-slate-600">Click to upload CR</p>
                  <p className="text-[9px] text-slate-400">PDF, JPG up to 5MB</p>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-500 font-semibold uppercase">Valid Insurance Card Copy</label>
                <div className="border border-dashed border-slate-200 rounded-lg p-4 text-center cursor-pointer hover:bg-slate-50 transition-colors">
                  <Upload className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                  <p className="text-[10px] font-bold text-slate-600">Click to upload Card</p>
                  <p className="text-[9px] text-slate-400">PDF, JPG up to 5MB</p>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                id="btn-owner-verify-submit"
                type="submit"
                className="px-5 py-2.5 text-xs font-black bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-sm"
              >
                Submit for Fast Verification Review
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Listing Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              id="add-vehicle-modal-body"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-2xl w-full p-6 md:p-8 overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto space-y-6"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 text-xl">List Your Vehicle For Free</h3>
                <button 
                  id="btn-close-add-modal"
                  onClick={() => setShowAddModal(false)}
                  className="p-1 rounded-full hover:bg-slate-100 text-slate-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateVehicle} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Listing Title</label>
                    <input
                      id="add-vehicle-title"
                      type="text"
                      required
                      placeholder="e.g. Toyota Aqua Hybrid 2017"
                      value={newVehicleData.title}
                      onChange={e => setNewVehicleData({...newVehicleData, title: e.target.value})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 focus:bg-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Vehicle Category</label>
                    <select
                      id="add-vehicle-type"
                      value={newVehicleData.type}
                      onChange={e => setNewVehicleData({...newVehicleData, type: e.target.value as Vehicle['type']})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 focus:bg-white"
                    >
                      {VEHICLE_TYPES.map(t => (
                        <option key={t.value} value={t.value}>{t.label}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Brand</label>
                    <input
                      id="add-vehicle-brand"
                      type="text"
                      required
                      placeholder="Toyota"
                      value={newVehicleData.brand}
                      onChange={e => setNewVehicleData({...newVehicleData, brand: e.target.value})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Model</label>
                    <input
                      id="add-vehicle-model"
                      type="text"
                      required
                      placeholder="Aqua"
                      value={newVehicleData.model}
                      onChange={e => setNewVehicleData({...newVehicleData, model: e.target.value})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Year</label>
                    <input
                      id="add-vehicle-year"
                      type="number"
                      required
                      placeholder="2017"
                      value={newVehicleData.year}
                      onChange={e => setNewVehicleData({...newVehicleData, year: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Transmission</label>
                    <select
                      id="add-vehicle-transmission"
                      value={newVehicleData.transmission}
                      onChange={e => setNewVehicleData({...newVehicleData, transmission: e.target.value as Vehicle['transmission']})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    >
                      <option value="automatic">Automatic</option>
                      <option value="manual">Manual</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Fuel Type</label>
                    <select
                      id="add-vehicle-fuel"
                      value={newVehicleData.fuelType}
                      onChange={e => setNewVehicleData({...newVehicleData, fuelType: e.target.value as Vehicle['fuelType']})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    >
                      <option value="petrol">Petrol</option>
                      <option value="diesel">Diesel</option>
                      <option value="hybrid">Hybrid</option>
                      <option value="electric">Electric</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Daily Rate (LKR)</label>
                    <input
                      id="add-vehicle-rate-lkr"
                      type="number"
                      required
                      placeholder="e.g. 6000"
                      value={newVehicleData.pricePerDayLKR}
                      onChange={e => setNewVehicleData({...newVehicleData, pricePerDayLKR: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Daily Rate (USD - Foreign Tourists)</label>
                    <input
                      id="add-vehicle-rate-usd"
                      type="number"
                      required
                      placeholder="e.g. 20"
                      value={newVehicleData.pricePerDayUSD}
                      onChange={e => setNewVehicleData({...newVehicleData, pricePerDayUSD: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Passenger Seats</label>
                    <input
                      id="add-vehicle-seats"
                      type="number"
                      required
                      value={newVehicleData.seats}
                      onChange={e => setNewVehicleData({...newVehicleData, seats: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Luggage Capacity</label>
                    <input
                      id="add-vehicle-luggage"
                      type="number"
                      required
                      value={newVehicleData.luggage}
                      onChange={e => setNewVehicleData({...newVehicleData, luggage: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Primary Location</label>
                    <select
                      id="add-vehicle-location"
                      value={newVehicleData.location}
                      onChange={e => setNewVehicleData({...newVehicleData, location: e.target.value})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    >
                      {LOCATIONS.map(loc => (
                        <option key={loc} value={loc}>{loc}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 font-semibold uppercase">Rental Offering Capabilities</label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-1.5 text-xs text-slate-600 font-bold">
                      <input
                        id="add-vehicle-cap-self"
                        type="checkbox"
                        checked={newVehicleData.isSelfDrive}
                        onChange={e => setNewVehicleData({...newVehicleData, isSelfDrive: e.target.checked})}
                        className="rounded border-slate-200 text-blue-600"
                      />
                      Self-Drive
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-slate-600 font-bold">
                      <input
                        id="add-vehicle-cap-driver"
                        type="checkbox"
                        checked={newVehicleData.isWithDriver}
                        onChange={e => setNewVehicleData({...newVehicleData, isWithDriver: e.target.checked})}
                        className="rounded border-slate-200 text-blue-600"
                      />
                      With Driver
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-slate-600 font-bold">
                      <input
                        id="add-vehicle-cap-airport"
                        type="checkbox"
                        checked={newVehicleData.isAirportPickup}
                        onChange={e => setNewVehicleData({...newVehicleData, isAirportPickup: e.target.checked})}
                        className="rounded border-slate-200 text-blue-600"
                      />
                      Airport Pickup Available
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Security Deposit (LKR)</label>
                    <input
                      id="add-vehicle-deposit-lkr"
                      type="number"
                      required
                      placeholder="15000"
                      value={newVehicleData.depositLKR}
                      onChange={e => setNewVehicleData({...newVehicleData, depositLKR: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Security Deposit (USD)</label>
                    <input
                      id="add-vehicle-deposit-usd"
                      type="number"
                      required
                      placeholder="50"
                      value={newVehicleData.depositUSD}
                      onChange={e => setNewVehicleData({...newVehicleData, depositUSD: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Mileage Allowance Limit</label>
                    <input
                      id="add-vehicle-mileage"
                      type="text"
                      required
                      placeholder="e.g. 120 km/day"
                      value={newVehicleData.mileageLimit}
                      onChange={e => setNewVehicleData({...newVehicleData, mileageLimit: e.target.value})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-semibold uppercase">Extra Mileage Fee (LKR/km)</label>
                    <input
                      id="add-vehicle-mileage-charge"
                      type="number"
                      required
                      placeholder="40"
                      value={newVehicleData.extraMileageCharge}
                      onChange={e => setNewVehicleData({...newVehicleData, extraMileageCharge: Number(e.target.value)})}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 font-semibold uppercase">Rules & Handover requirements (separate by semi-colon ;)</label>
                  <textarea
                    id="add-vehicle-rules"
                    rows={2}
                    required
                    placeholder="e.g. Return with same fuel level; International License with endorsements required; No smoking inside"
                    value={newVehicleData.rules}
                    onChange={e => setNewVehicleData({...newVehicleData, rules: e.target.value})}
                    className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none resize-none"
                  />
                </div>

                <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 text-[11px] text-blue-800 space-y-1">
                  <p className="font-bold">✨ Live Integration Ready</p>
                  <p>Our free launch model skips payment gateway approvals. Your listing goes directly into the "Admin Review Queue", and you can approve it yourself instantly inside the <b>Admin Review Board</b> tab above to test the entire marketplace flow!</p>
                </div>

                <div className="flex gap-2 justify-end border-t border-slate-100 pt-4">
                  <button
                    id="btn-add-vehicle-cancel"
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 text-xs font-semibold bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    id="btn-add-vehicle-submit"
                    type="submit"
                    className="px-5 py-2 text-xs font-black bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-sm"
                  >
                    Submit for Review
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
