/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Calendar, 
  Search, 
  Star, 
  ShieldCheck, 
  User, 
  Phone, 
  SlidersHorizontal, 
  Check, 
  X, 
  Briefcase, 
  Fuel, 
  Sparkles, 
  Camera, 
  CheckCircle2, 
  Plane, 
  Bike, 
  Car, 
  AlertCircle, 
  ArrowRight,
  Info
} from 'lucide-react';
import { Vehicle, BookingRequest, Review } from '../types';
import { LOCATIONS, VEHICLE_TYPES, BADGE_DESCRIPTIONS, SAMPLE_REVIEWS } from '../data';

interface CustomerPortalProps {
  vehicles: Vehicle[];
  bookings: BookingRequest[];
  onAddBooking: (booking: BookingRequest) => void;
  onUpdateBookingStatus: (bookingId: string, status: BookingRequest['status']) => void;
  onUploadPhotos: (bookingId: string, stage: 'pickup' | 'return', photos: string[]) => void;
}

export default function CustomerPortal({
  vehicles,
  bookings,
  onAddBooking,
  onUpdateBookingStatus,
  onUploadPhotos
}: CustomerPortalProps) {
  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [rentalTypeFilter, setRentalTypeFilter] = useState<'all' | 'self-drive' | 'with-driver' | 'airport-pickup'>('all');
  const [priceRange, setPriceRange] = useState<number>(100); // USD per day max
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);

  // Selected Vehicle for Detail Modal
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  
  // Interactive Booking Request Form State
  const [bookingFormData, setBookingFormData] = useState({
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    customerCountry: '',
    startDate: '',
    endDate: '',
    rentalType: 'self-drive' as BookingRequest['rentalType'],
    pickupLocation: '',
    returnLocation: '',
    notes: ''
  });

  // Booking process animation step
  const [bookingStep, setBookingStep] = useState<'idle' | 'submitting' | 'checking_rules' | 'verified_checks' | 'success'>('idle');
  const [lastCreatedBookingId, setLastCreatedBookingId] = useState<string | null>(null);

  // Active Tab for User: "Find Vehicles" vs "My Bookings"
  const [activeTab, setActiveTab] = useState<'explore' | 'bookings'>('explore');

  // Interactive Upload State
  const [uploadingBookingId, setUploadingBookingId] = useState<string | null>(null);
  const [uploadStage, setUploadStage] = useState<'pickup' | 'return' | null>(null);
  const [uploadedUrls, setUploadedUrls] = useState<string[]>([]);

  // Filtered vehicles
  const filteredVehicles = useMemo(() => {
    return vehicles.filter(v => {
      if (!v.isApproved) return false;
      
      const matchesSearch = v.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            v.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            v.model.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesLocation = selectedLocation === 'all' || v.location === selectedLocation;
      
      const matchesType = selectedType === 'all' || v.type === selectedType;
      
      const matchesRentalType = rentalTypeFilter === 'all' ||
        (rentalTypeFilter === 'self-drive' && v.isSelfDrive) ||
        (rentalTypeFilter === 'with-driver' && v.isWithDriver) ||
        (rentalTypeFilter === 'airport-pickup' && v.isAirportPickup);
        
      const matchesPrice = v.pricePerDayUSD <= priceRange;

      return matchesSearch && matchesLocation && matchesType && matchesRentalType && matchesPrice;
    });
  }, [vehicles, searchQuery, selectedLocation, selectedType, rentalTypeFilter, priceRange]);

  // Handle vehicle card click
  const handleOpenDetails = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    // Initialize booking form defaults
    setBookingFormData({
      customerName: 'Marcus Aurelius',
      customerEmail: 'marcus.travels@gmail.com',
      customerPhone: '+44 7911 123456',
      customerCountry: 'United Kingdom',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 3 days later
      rentalType: vehicle.isSelfDrive ? 'self-drive' : 'with-driver',
      pickupLocation: vehicle.location,
      returnLocation: vehicle.location,
      notes: 'Visiting Sri Lanka for a 2-week surfing trip. Looking forward to exploring!'
    });
    setBookingStep('idle');
  };

  // Handle booking form submission
  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicle) return;

    setBookingStep('submitting');

    // Simulate stepping through the modern DriveLink automated trust engine checks
    setTimeout(() => {
      setBookingStep('checking_rules');
      setTimeout(() => {
        setBookingStep('verified_checks');
        setTimeout(() => {
          // Complete booking object creation
          const start = new Date(bookingFormData.startDate);
          const end = new Date(bookingFormData.endDate);
          const totalDays = Math.max(1, Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
          const totalPriceUSD = totalDays * selectedVehicle.pricePerDayUSD;
          const totalPriceLKR = totalDays * selectedVehicle.pricePerDayLKR;

          const newBooking: BookingRequest = {
            id: `b_${Date.now().toString().slice(-6)}`,
            vehicleId: selectedVehicle.id,
            vehicleTitle: selectedVehicle.title,
            vehicleImage: selectedVehicle.image,
            vehiclePrice: selectedVehicle.pricePerDayUSD,
            customerName: bookingFormData.customerName,
            customerEmail: bookingFormData.customerEmail,
            customerPhone: bookingFormData.customerPhone,
            customerCountry: bookingFormData.customerCountry,
            startDate: bookingFormData.startDate,
            endDate: bookingFormData.endDate,
            rentalType: bookingFormData.rentalType,
            pickupLocation: bookingFormData.pickupLocation,
            returnLocation: bookingFormData.returnLocation,
            totalDays,
            totalPrice: totalPriceUSD,
            status: 'pending', // Pending Admin & Owner review
            createdAt: new Date().toLocaleDateString(),
            notes: bookingFormData.notes,
            pickupPhotos: [],
            returnPhotos: []
          };

          onAddBooking(newBooking);
          setLastCreatedBookingId(newBooking.id);
          setBookingStep('success');
        }, 1200);
      }, 1200);
    }, 1000);
  };

  // Get specific reviews for selected vehicle
  const vehicleReviews = useMemo(() => {
    if (!selectedVehicle) return [];
    return SAMPLE_REVIEWS.filter(r => r.vehicleId === selectedVehicle.id);
  }, [selectedVehicle]);

  // Handle simulated photo upload
  const handleSimulatedUpload = (bookingId: string, stage: 'pickup' | 'return') => {
    setUploadingBookingId(bookingId);
    setUploadStage(stage);
    
    // Some mock rental condition photo options
    const mockPhotos = stage === 'pickup' 
      ? [
          'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=400',
          'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=400'
        ]
      : [
          'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=400'
        ];
    
    setUploadedUrls(mockPhotos);
  };

  const saveUploadedPhotos = () => {
    if (uploadingBookingId && uploadStage) {
      onUploadPhotos(uploadingBookingId, uploadStage, uploadedUrls);
      setUploadingBookingId(null);
      setUploadStage(null);
      setUploadedUrls([]);
    }
  };

  return (
    <div className="space-y-8">
      {/* Halo Header */}
      <div className="relative rounded-2xl overflow-hidden bg-slate-900 text-white p-8 md:p-12 shadow-xl">
        <div className="absolute inset-0 z-0 opacity-40">
          <img 
            src="/src/assets/images/sri_lanka_hero_1782492619890.jpg" 
            alt="Sri Lanka Coastline" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900 to-transparent" />
        </div>

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5" /> Sri Lanka's Verified Rental Network
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight">
            Safer discovery. <br />
            <span className="text-blue-400">Zero platform fees.</span>
          </h1>
          <p className="text-slate-300 text-sm md:text-base leading-relaxed">
            DriveLink connects you with verified local owners, tour guides, and agencies. Self-drive options with licensing help, or professional local guides who know the island inside out.
          </p>
          
          <div className="flex flex-wrap gap-3 pt-2">
            <button 
              id="btn-customer-explore"
              onClick={() => { setActiveTab('explore'); }}
              className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
                activeTab === 'explore' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                  : 'bg-white/10 hover:bg-white/15 text-white backdrop-blur-md'
              }`}
            >
              Explore Vehicles
            </button>
            <button 
              id="btn-customer-bookings"
              onClick={() => { setActiveTab('bookings'); }}
              className={`px-5 py-2.5 rounded-lg font-medium relative transition-all ${
                activeTab === 'bookings' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                  : 'bg-white/10 hover:bg-white/15 text-white backdrop-blur-md'
              }`}
            >
              My Bookings
              {bookings.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">
                  {bookings.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'explore' ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters - Left Sidebar (Desktop) */}
          <div className="lg:col-span-1 space-y-6 bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-fit">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-blue-600" /> Filters
              </h3>
              <button 
                id="btn-clear-filters"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedLocation('all');
                  setSelectedType('all');
                  setRentalTypeFilter('all');
                  setPriceRange(100);
                }}
                className="text-xs text-slate-400 hover:text-blue-600 transition-colors"
              >
                Reset All
              </button>
            </div>

            {/* Keyword Search */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input
                  id="filter-search-input"
                  type="text"
                  placeholder="Toyota, Royal Enfield..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 focus:bg-white transition-colors"
                />
              </div>
            </div>

            {/* Location Select */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Location</label>
              <select
                id="filter-location-select"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 focus:bg-white transition-colors"
              >
                <option value="all">Anywhere in Sri Lanka</option>
                {LOCATIONS.map(loc => (
                  <option key={loc} value={loc}>{loc}</option>
                ))}
              </select>
            </div>

            {/* Vehicle Type */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Vehicle Type</label>
              <div className="flex flex-col gap-1">
                <button
                  id={`type-filter-all`}
                  onClick={() => setSelectedType('all')}
                  className={`text-left px-3 py-2 text-sm rounded-lg transition-all ${
                    selectedType === 'all' 
                      ? 'bg-blue-50 text-blue-700 font-medium' 
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  All Categories
                </button>
                {VEHICLE_TYPES.map(t => (
                  <button
                    key={t.value}
                    id={`type-filter-${t.value}`}
                    onClick={() => setSelectedType(t.value)}
                    className={`text-left px-3 py-2 text-sm rounded-lg transition-all ${
                      selectedType === t.value 
                        ? 'bg-blue-50 text-blue-700 font-medium' 
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Service Filter */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Rental Option</label>
              <div className="grid grid-cols-2 gap-2">
                {(['all', 'self-drive', 'with-driver', 'airport-pickup'] as const).map(option => (
                  <button
                    key={option}
                    id={`rental-option-${option}`}
                    onClick={() => setRentalTypeFilter(option)}
                    className={`px-2 py-1.5 text-xs rounded-lg border text-center font-medium capitalize transition-all ${
                      rentalTypeFilter === option
                        ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {option === 'all' ? 'Any Option' : option.replace('-', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Price slider */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>Max Budget</span>
                <span className="text-blue-600 font-bold">${priceRange}/day</span>
              </div>
              <input
                id="price-range-slider"
                type="range"
                min="5"
                max="120"
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>$5/day</span>
                <span>$120/day</span>
              </div>
            </div>

            {/* Strategy Note Card */}
            <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 space-y-2">
              <h4 className="text-xs font-bold text-blue-800 flex items-center gap-1">
                <Info className="w-3.5 h-3.5" /> DriveLink Advantage
              </h4>
              <p className="text-[11px] text-blue-700 leading-relaxed">
                Direct provider contracts, zero added service commissions during free launch period. You pay the exact listed local price.
              </p>
            </div>
          </div>

          {/* Vehicles Catalog */}
          <div className="lg:col-span-3 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-800">Verified Vehicles</h2>
                <p className="text-xs text-slate-400">Showing {filteredVehicles.length} of {vehicles.length} tourist-ready options</p>
              </div>
              
              {/* Popular destinations shortcuts */}
              <div className="hidden sm:flex items-center gap-2">
                <span className="text-xs text-slate-400 font-medium">Quick locations:</span>
                {['Negombo', 'Colombo', 'Ella', 'Mirissa'].map(loc => (
                  <button
                    key={loc}
                    id={`shortcut-loc-${loc}`}
                    onClick={() => setSelectedLocation(loc)}
                    className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                      selectedLocation === loc 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                    }`}
                  >
                    {loc}
                  </button>
                ))}
              </div>
            </div>

            {filteredVehicles.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-slate-100 text-center space-y-4">
                <div className="h-16 w-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                  <Search className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-700">No vehicles match your filters</h3>
                  <p className="text-xs text-slate-400 max-w-sm mt-1">Try resetting the keyword search or widening the location and rental option filters.</p>
                </div>
                <button
                  id="btn-no-results-reset"
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedLocation('all');
                    setSelectedType('all');
                    setRentalTypeFilter('all');
                    setPriceRange(100);
                  }}
                  className="px-4 py-2 text-xs font-semibold bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredVehicles.map((vehicle) => (
                  <motion.div
                    key={vehicle.id}
                    id={`vehicle-card-${vehicle.id}`}
                    layoutId={`vehicle-container-${vehicle.id}`}
                    onClick={() => handleOpenDetails(vehicle)}
                    className="group bg-white rounded-xl border border-slate-100 overflow-hidden cursor-pointer shadow-sm hover:shadow-md transition-all flex flex-col"
                    whileHover={{ y: -4 }}
                  >
                    {/* Vehicle Image */}
                    <div className="relative aspect-video bg-slate-100 overflow-hidden">
                      <img 
                        src={vehicle.image} 
                        alt={vehicle.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Floating Location */}
                      <div className="absolute top-3 left-3 px-2 py-1 rounded-md text-[10px] font-bold bg-slate-900/80 text-white backdrop-blur-md flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-blue-400" /> {vehicle.location}
                      </div>

                      {/* Floating badges indicator */}
                      <div className="absolute bottom-3 right-3 flex flex-col gap-1 items-end">
                        {vehicle.isSelfDrive && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-blue-600 text-white shadow-sm">
                            Self-Drive
                          </span>
                        )}
                        {vehicle.isWithDriver && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-amber-500 text-slate-950 shadow-sm">
                            With Driver
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Card Content */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        {/* Rating and Reviews */}
                        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                          <div className="flex items-center gap-0.5 text-amber-500">
                            <Star className="w-3.5 h-3.5 fill-current" />
                            <span className="font-bold text-slate-800">{vehicle.ownerRating}</span>
                          </div>
                          <span>•</span>
                          <span>{vehicle.reviewsCount} reviews</span>
                        </div>

                        <h3 className="font-bold text-slate-800 mt-1 line-clamp-1 group-hover:text-blue-600 transition-colors">
                          {vehicle.title}
                        </h3>

                        {/* Specs row */}
                        <div className="flex items-center gap-3 text-slate-400 text-xs mt-2 font-medium">
                          <span className="flex items-center gap-1 capitalize">
                            <Car className="w-3.5 h-3.5" /> {vehicle.transmission}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Briefcase className="w-3.5 h-3.5" /> {vehicle.seats} seats
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Fuel className="w-3.5 h-3.5" /> {vehicle.fuelType}
                          </span>
                        </div>
                      </div>

                      {/* Verification Badge list preview */}
                      <div className="flex flex-wrap gap-1">
                        {vehicle.badges.slice(0, 3).map((badge) => (
                          <span 
                            key={badge} 
                            className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-semibold border border-blue-100"
                          >
                            <ShieldCheck className="w-2.5 h-2.5 text-blue-500" /> {badge}
                          </span>
                        ))}
                        {vehicle.badges.length > 3 && (
                          <span className="px-1 py-0.5 rounded bg-slate-50 text-slate-400 text-[9px] font-bold">
                            +{vehicle.badges.length - 3} more
                          </span>
                        )}
                      </div>

                      {/* Price tag */}
                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <div className="text-xs text-slate-400 font-medium">Daily Rate</div>
                          <div className="flex items-baseline gap-1">
                            <span className="text-lg font-extrabold text-slate-800">${vehicle.pricePerDayUSD}</span>
                            <span className="text-xs text-slate-400 font-medium">/ USD</span>
                            <span className="text-xs text-slate-400 px-1 font-normal">
                              (~LKR {vehicle.pricePerDayLKR.toLocaleString()})
                            </span>
                          </div>
                        </div>

                        <span className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                          <ArrowRight className="w-4 h-4" />
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* My Bookings Tracker View */
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-800">My Rental Bookings</h2>
              <p className="text-xs text-slate-400">Track current trip requests, deposit releases, and status checks</p>
            </div>
          </div>

          {bookings.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-slate-200 text-center space-y-4 shadow-sm">
              <div className="h-16 w-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                <Calendar className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-700">No active bookings yet</h3>
                <p className="text-xs text-slate-400 max-w-sm mt-1">When you request a vehicle rental, your booking records and owner communication routing will appear here.</p>
              </div>
              <button
                id="btn-no-bookings-explore"
                onClick={() => setActiveTab('explore')}
                className="px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors"
              >
                Find Vehicles Now
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {bookings.map((booking) => {
                const isPending = booking.status === 'pending';
                const isVerified = booking.status === 'verified';
                const isApproved = booking.status === 'approved_by_owner';
                const isCompleted = booking.status === 'completed';
                const isRejected = booking.status === 'rejected';

                return (
                  <div key={booking.id} className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm flex flex-col md:flex-row">
                    {/* Visual Card Side */}
                    <div className="w-full md:w-64 relative bg-slate-100 aspect-video md:aspect-auto">
                      <img 
                        src={booking.vehicleImage} 
                        alt={booking.vehicleTitle} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-3 left-3 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900/80 text-white backdrop-blur-md">
                        ID: {booking.id}
                      </div>
                    </div>

                    {/* Booking core details */}
                    <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                      <div>
                        {/* Header status */}
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                            Created on {booking.createdAt}
                          </span>
                          
                          {/* Rich Status Badges */}
                          <div className="flex items-center gap-2">
                            {isPending && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                                <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" /> Sent to Admin
                              </span>
                            )}
                            {isVerified && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                                <span className="h-1.5 w-1.5 rounded-full bg-blue-500" /> Documents Verified
                              </span>
                            )}
                            {isApproved && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Approved by Owner
                              </span>
                            )}
                            {isCompleted && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-50 text-slate-600 border border-slate-200">
                                <span className="h-1.5 w-1.5 rounded-full bg-slate-500" /> Trip Completed
                              </span>
                            )}
                            {isRejected && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                                <span className="h-1.5 w-1.5 rounded-full bg-rose-500" /> Booking Declined
                              </span>
                            )}
                          </div>
                        </div>

                        <h3 className="font-bold text-slate-800 text-lg mt-1">{booking.vehicleTitle}</h3>

                        {/* Meta info columns */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
                          <div>
                            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Rental Type</div>
                            <div className="text-xs font-bold text-slate-700 capitalize flex items-center gap-1 mt-0.5">
                              {booking.rentalType === 'self-drive' ? <Car className="w-3.5 h-3.5 text-blue-600" /> : <User className="w-3.5 h-3.5 text-amber-500" />}
                              {booking.rentalType.replace('-', ' ')}
                            </div>
                          </div>
                          <div>
                            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Duration</div>
                            <div className="text-xs font-bold text-slate-700 mt-0.5">
                              {booking.totalDays} Days ({booking.startDate} to {booking.endDate})
                            </div>
                          </div>
                          <div>
                            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Route / Locations</div>
                            <div className="text-xs font-bold text-slate-700 mt-0.5">
                              {booking.pickupLocation} → {booking.returnLocation}
                            </div>
                          </div>
                          <div>
                            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Total Booking Cost</div>
                            <div className="text-xs font-bold text-slate-800 mt-0.5 flex items-baseline gap-1">
                              <span className="text-blue-700 font-extrabold text-sm">${booking.totalPrice}</span>
                              <span className="text-[10px] text-slate-400 font-normal"> (~LKR {(booking.totalPrice * 300).toLocaleString()})</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Interactive Step Timeline (Tourist Trust Engine Checklist) */}
                      <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          DriveLink Secure Verification Steps
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center text-xs">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-blue-500" />
                            <div>
                              <p className="font-bold text-slate-700">1. Verification Check</p>
                              <p className="text-[10px] text-slate-400">Admin checks customer details & licenses</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${isPending ? 'bg-amber-100 text-amber-700 font-bold' : 'bg-blue-600 text-white'}`}>
                              {isPending ? '2' : <Check className="w-3 h-3" />}
                            </div>
                            <div>
                              <p className={`font-bold ${isPending ? 'text-slate-400' : 'text-slate-700'}`}>2. Provider Handshake</p>
                              <p className="text-[10px] text-slate-400">Owner confirms availability</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${isPending || isVerified ? 'bg-slate-100 text-slate-400' : isApproved ? 'bg-amber-100 text-amber-700 font-bold' : 'bg-blue-600 text-white'}`}>
                              {isPending || isVerified ? '3' : isApproved ? '3' : <Check className="w-3 h-3" />}
                            </div>
                            <div>
                              <p className={`font-bold ${isPending || isVerified ? 'text-slate-400' : 'text-slate-700'}`}>3. Handover & Condition</p>
                              <p className="text-[10px] text-slate-400">Photos of fuel/odometer/scratches</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Interactive Actions - Photo uploads for Condition verification (Section 18 lists: "Highest priority: Pickup/return photo upload") */}
                      <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100">
                        {/* Left Side: Contact details of Owner displayed after Admin approval */}
                        {!isPending ? (
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-700">
                              PR
                            </div>
                            <div>
                              <p className="text-[10px] text-slate-400 font-semibold">Contact Partner Provider</p>
                              <p className="text-xs font-bold text-slate-800">Pradeep Ranasinghe (+94 77 123 4567)</p>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-xs text-amber-600 font-medium">
                            <AlertCircle className="w-4 h-4" /> Owner details unlocked once Admin passes the documents check.
                          </div>
                        )}

                        {/* Right Side: Photo uploads during active state */}
                        {!isPending && !isRejected && (
                          <div className="flex items-center gap-2">
                            {/* Pickup Photos Trigger */}
                            <div className="space-y-1">
                              <button
                                id={`btn-upload-pickup-${booking.id}`}
                                onClick={() => handleSimulatedUpload(booking.id, 'pickup')}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                              >
                                <Camera className="w-3.5 h-3.5" /> 
                                {booking.pickupPhotos && booking.pickupPhotos.length > 0 ? 'Update Pickup Photos' : 'Upload Pickup Photos'}
                              </button>
                              {booking.pickupPhotos && booking.pickupPhotos.length > 0 && (
                                <p className="text-[9px] text-blue-600 font-bold flex items-center gap-0.5 justify-center">
                                  <Check className="w-2.5 h-2.5" /> {booking.pickupPhotos.length} photos uploaded
                                </p>
                              )}
                            </div>

                            {/* Return Photos Trigger */}
                            {booking.pickupPhotos && booking.pickupPhotos.length > 0 && (
                              <div className="space-y-1">
                                <button
                                  id={`btn-upload-return-${booking.id}`}
                                  onClick={() => handleSimulatedUpload(booking.id, 'return')}
                                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                                >
                                  <Camera className="w-3.5 h-3.5" /> 
                                  {booking.returnPhotos && booking.returnPhotos.length > 0 ? 'Update Return Photos' : 'Upload Return Photos'}
                                </button>
                                {booking.returnPhotos && booking.returnPhotos.length > 0 && (
                                  <p className="text-[9px] text-blue-600 font-bold flex items-center gap-0.5 justify-center">
                                    <Check className="w-2.5 h-2.5" /> {booking.returnPhotos.length} photos uploaded
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Detail & Booking Sheet/Modal */}
      <AnimatePresence>
        {selectedVehicle && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              id="detail-modal-body"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]"
            >
              {/* Left Side: Vehicle Photos, Specs, Rules */}
              <div className="md:w-1/2 overflow-y-auto p-6 md:p-8 space-y-6 border-b md:border-b-0 md:border-r border-slate-100 max-h-[90vh]">
                <div className="relative rounded-xl overflow-hidden aspect-video bg-slate-100">
                  <img 
                    src={selectedVehicle.image} 
                    alt={selectedVehicle.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute top-3 left-3 px-2 py-1 rounded bg-slate-900/80 text-white font-bold text-xs flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" /> {selectedVehicle.location}
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mb-1">
                    <span className="uppercase tracking-wider">{selectedVehicle.brand}</span>
                    <span>•</span>
                    <span>{selectedVehicle.year}</span>
                  </div>
                  <h2 className="text-2xl font-black text-slate-800 tracking-tight leading-tight">
                    {selectedVehicle.title}
                  </h2>
                  <div className="flex items-center gap-1 mt-2 text-xs font-bold text-slate-700">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" /> {selectedVehicle.ownerRating} ({selectedVehicle.reviewsCount} verified reviews)
                  </div>
                </div>

                {/* Specs Box */}
                <div className="grid grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl">
                  <div className="text-center space-y-0.5">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Transmission</p>
                    <p className="text-xs font-bold text-slate-700 capitalize">{selectedVehicle.transmission}</p>
                  </div>
                  <div className="text-center space-y-0.5">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Fuel Type</p>
                    <p className="text-xs font-bold text-slate-700 capitalize">{selectedVehicle.fuelType}</p>
                  </div>
                  <div className="text-center space-y-0.5">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Seats</p>
                    <p className="text-xs font-bold text-slate-700">{selectedVehicle.seats} Persons</p>
                  </div>
                </div>

                {/* Deposit & Limits Rules */}
                <div className="space-y-3">
                  <h4 className="font-bold text-slate-800 text-sm">Rental Handover Rules & Limits</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1.5 border-b border-slate-100">
                      <span className="text-slate-400 font-medium">Refundable Deposit</span>
                      <span className="font-bold text-slate-700">
                        {selectedVehicle.depositUSD > 0 ? `$${selectedVehicle.depositUSD} / LKR ${selectedVehicle.depositLKR.toLocaleString()}` : 'No Deposit Needed'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-100">
                      <span className="text-slate-400 font-medium">Mileage Allowance</span>
                      <span className="font-bold text-slate-700">{selectedVehicle.mileageLimit}</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-100">
                      <span className="text-slate-400 font-medium">Extra Mileage Fee</span>
                      <span className="font-bold text-slate-700">LKR {selectedVehicle.extraMileageCharge}/km</span>
                    </div>
                  </div>
                </div>

                {/* Owner details card */}
                <div className="p-4 rounded-xl border border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img 
                      src={selectedVehicle.ownerAvatar} 
                      alt={selectedVehicle.ownerName} 
                      className="w-10 h-10 rounded-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <p className="text-[10px] text-slate-400 font-semibold">Registered Host</p>
                      <h4 className="text-xs font-bold text-slate-800">{selectedVehicle.ownerName}</h4>
                      <div className="flex items-center gap-1 text-[10px] text-slate-400 font-bold">
                        <span className="text-blue-600">Verified</span>
                        <span>•</span>
                        <span>Replies {selectedVehicle.ownerResponseTime}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Rules List */}
                <div className="space-y-2">
                  <h4 className="font-bold text-slate-800 text-sm">Handover Requirements</h4>
                  <ul className="space-y-2">
                    {selectedVehicle.rules.map((rule, idx) => (
                      <li key={idx} className="flex gap-2 text-xs text-slate-600 leading-relaxed">
                        <span className="text-blue-500 font-bold">•</span>
                        <span>{rule}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Reviews List */}
                <div className="space-y-3 pt-2">
                  <h4 className="font-bold text-slate-800 text-sm">Guest Reviews</h4>
                  {vehicleReviews.length === 0 ? (
                    <p className="text-xs text-slate-400 italic">No direct reviews listed for this unit yet. Rated 5 stars across other provider listings.</p>
                  ) : (
                    <div className="space-y-4">
                      {vehicleReviews.map(rev => (
                        <div key={rev.id} className="space-y-1.5 bg-slate-50 p-3 rounded-lg border border-slate-100">
                           <div className="flex justify-between items-center text-[10px]">
                            <span className="font-bold text-slate-700">{rev.authorName} ({rev.authorCountry})</span>
                            <span className="text-slate-400">{rev.date}</span>
                          </div>
                          <div className="flex text-amber-400">
                            {Array.from({ length: rev.rating }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-current" />
                            ))}
                          </div>
                          <p className="text-xs text-slate-600 italic leading-normal">"{rev.comment}"</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Right Side: Interactive Booking Request Form & Animation */}
              <div className="md:w-1/2 overflow-y-auto p-6 md:p-8 flex flex-col justify-between bg-slate-50/50 max-h-[90vh]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-800 text-lg">Send Booking Inquiry</h3>
                  <button 
                    id="btn-close-modal"
                    onClick={() => setSelectedVehicle(null)}
                    className="p-1 rounded-full hover:bg-slate-100 text-slate-400 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {bookingStep === 'idle' ? (
                  <form onSubmit={handleConfirmBooking} className="space-y-4 flex-1">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Your Full Name</label>
                        <input
                          id="booking-name"
                          type="text"
                          required
                          value={bookingFormData.customerName}
                          onChange={e => setBookingFormData({...bookingFormData, customerName: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Country of Origin</label>
                        <input
                          id="booking-country"
                          type="text"
                          required
                          value={bookingFormData.customerCountry}
                          onChange={e => setBookingFormData({...bookingFormData, customerCountry: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Email Address</label>
                        <input
                          id="booking-email"
                          type="email"
                          required
                          value={bookingFormData.customerEmail}
                          onChange={e => setBookingFormData({...bookingFormData, customerEmail: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">WhatsApp Number</label>
                        <input
                          id="booking-phone"
                          type="tel"
                          required
                          value={bookingFormData.customerPhone}
                          onChange={e => setBookingFormData({...bookingFormData, customerPhone: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Pickup Date</label>
                        <input
                          id="booking-start"
                          type="date"
                          required
                          value={bookingFormData.startDate}
                          onChange={e => setBookingFormData({...bookingFormData, startDate: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Return Date</label>
                        <input
                          id="booking-end"
                          type="date"
                          required
                          value={bookingFormData.endDate}
                          onChange={e => setBookingFormData({...bookingFormData, endDate: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-semibold text-slate-400 uppercase">Choose Rental Service Type</label>
                      <div className="grid grid-cols-3 gap-2">
                        {selectedVehicle.isSelfDrive && (
                          <button
                            id="btn-rent-self"
                            type="button"
                            onClick={() => setBookingFormData({...bookingFormData, rentalType: 'self-drive'})}
                            className={`px-2 py-2 text-xs border rounded-lg font-bold text-center capitalize ${
                              bookingFormData.rentalType === 'self-drive'
                                ? 'bg-blue-50 border-blue-500 text-blue-800'
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            Self Drive
                          </button>
                        )}
                        {selectedVehicle.isWithDriver && (
                          <button
                            id="btn-rent-driver"
                            type="button"
                            onClick={() => setBookingFormData({...bookingFormData, rentalType: 'with-driver'})}
                            className={`px-2 py-2 text-xs border rounded-lg font-bold text-center capitalize ${
                              bookingFormData.rentalType === 'with-driver'
                                ? 'bg-blue-50 border-blue-500 text-blue-800'
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            With Driver
                          </button>
                        )}
                        {selectedVehicle.isAirportPickup && (
                          <button
                            id="btn-rent-airport"
                            type="button"
                            onClick={() => setBookingFormData({...bookingFormData, rentalType: 'airport-pickup'})}
                            className={`px-2 py-2 text-xs border rounded-lg font-bold text-center capitalize ${
                              bookingFormData.rentalType === 'airport-pickup'
                                ? 'bg-blue-50 border-blue-500 text-blue-800'
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            Airport Pickup
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Pickup Location</label>
                        <input
                          id="booking-pickup-loc"
                          type="text"
                          required
                          value={bookingFormData.pickupLocation}
                          onChange={e => setBookingFormData({...bookingFormData, pickupLocation: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase">Return Location</label>
                        <input
                          id="booking-return-loc"
                          type="text"
                          required
                          value={bookingFormData.returnLocation}
                          onChange={e => setBookingFormData({...bookingFormData, returnLocation: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-semibold text-slate-400 uppercase">Additional Travel Details (Optional)</label>
                      <textarea
                        id="booking-notes"
                        rows={2}
                        value={bookingFormData.notes}
                        onChange={e => setBookingFormData({...bookingFormData, notes: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 resize-none"
                      />
                    </div>

                    {/* Cost Preview Box */}
                    <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl space-y-2">
                      <div className="flex justify-between items-baseline text-xs text-blue-800 font-semibold">
                        <span>LKR Daily Cost</span>
                        <span className="font-extrabold text-sm">LKR {selectedVehicle.pricePerDayLKR.toLocaleString()}/day</span>
                      </div>
                      <div className="flex justify-between items-baseline text-slate-700">
                        <span className="text-xs font-semibold">DriveLink Total Fee</span>
                        <div className="text-right">
                          <p className="font-extrabold text-base text-blue-700">
                            ${Math.max(1, Math.round((new Date(bookingFormData.endDate).getTime() - new Date(bookingFormData.startDate).getTime()) / (1000 * 60 * 60 * 24))) * selectedVehicle.pricePerDayUSD} USD
                          </p>
                          <p className="text-[10px] text-slate-400">
                            (~LKR {(Math.max(1, Math.round((new Date(bookingFormData.endDate).getTime() - new Date(bookingFormData.startDate).getTime()) / (1000 * 60 * 60 * 24))) * selectedVehicle.pricePerDayLKR).toLocaleString()})
                          </p>
                        </div>
                      </div>
                      <p className="text-[10px] text-blue-700 leading-normal">
                        *No booking fees or down payments required. You pay the rental host directly upon handover.
                      </p>
                    </div>

                    <button
                      id="btn-submit-booking"
                      type="submit"
                      className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm rounded-xl transition-colors shadow-lg shadow-blue-600/10"
                    >
                      Verify License & Send Inquiry
                    </button>
                  </form>
                ) : (
                  /* Interactive Stepper Animation representing DriveLink high-converting trust systems */
                  <div className="flex-1 flex flex-col justify-center items-center space-y-8 p-6 text-center">
                    {bookingStep === 'submitting' && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-4"
                      >
                        <div className="h-12 w-12 rounded-full border-4 border-blue-600 border-t-transparent animate-spin mx-auto" />
                        <h4 className="font-bold text-slate-800">Transmitting Request</h4>
                        <p className="text-xs text-slate-400 max-w-xs">Initializing contact protocols and reserving temporary calendar slots with {selectedVehicle.ownerName}.</p>
                      </motion.div>
                    )}

                    {bookingStep === 'checking_rules' && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-4"
                      >
                        <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mx-auto">
                          <ShieldCheck className="w-6 h-6 animate-pulse" />
                        </div>
                        <h4 className="font-bold text-slate-800">Reviewing License Rules</h4>
                        <p className="text-xs text-slate-400 max-w-xs">Verifying permit requirements for {bookingFormData.customerCountry} visitors driving in Sri Lanka.</p>
                      </motion.div>
                    )}

                    {bookingStep === 'verified_checks' && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-4"
                      >
                        <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mx-auto">
                          <CheckCircle2 className="w-6 h-6 animate-pulse" />
                        </div>
                        <h4 className="font-bold text-slate-800">Passing Verification Seal</h4>
                        <p className="text-xs text-slate-400 max-w-xs">DriveLink automated check approved. Tagging listing with verification badge and creating secure record.</p>
                      </motion.div>
                    )}

                    {bookingStep === 'success' && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="space-y-6"
                      >
                        <div className="h-16 w-16 rounded-full bg-blue-600 text-white flex items-center justify-center text-3xl mx-auto shadow-lg shadow-blue-600/20">
                          <Check className="w-8 h-8" />
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-black text-slate-800 text-lg">Inquiry Successfully Sent!</h4>
                          <p className="text-xs text-slate-500 max-w-xs mx-auto">
                            Your reservation query for <span className="font-semibold">{selectedVehicle.title}</span> has been dispatched to {selectedVehicle.ownerName}.
                          </p>
                        </div>

                        <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-xs text-blue-800 text-left space-y-1">
                          <p className="font-bold">What happens next?</p>
                          <p>1. DriveLink administrators will review your uploaded license details.</p>
                          <p>2. The owner will accept the booking within 15 mins.</p>
                          <p>3. WhatsApp direct routing will unlock so you can sync coordinates.</p>
                        </div>

                        <div className="flex gap-2 justify-center">
                          <button
                            id="btn-goto-bookings"
                            onClick={() => {
                              setSelectedVehicle(null);
                              setActiveTab('bookings');
                            }}
                            className="px-4 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-lg transition-colors"
                          >
                            Track In My Bookings
                          </button>
                          <button
                            id="btn-continue-explore"
                            onClick={() => setSelectedVehicle(null)}
                            className="px-4 py-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                          >
                            Explore More
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Upload Condition Photos simulated Modal */}
      <AnimatePresence>
        {uploadingBookingId && uploadStage && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              id="upload-modal"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 capitalize flex items-center gap-1.5">
                  <Camera className="w-5 h-5 text-blue-600" /> Upload {uploadStage} Photos
                </h3>
                <button 
                  id="btn-close-upload"
                  onClick={() => { setUploadingBookingId(null); setUploadStage(null); }}
                  className="p-1 rounded-full hover:bg-slate-100 text-slate-400 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-slate-400">
                To protect against false damage claims, take photos of the vehicle condition (tires, fuel gauge, odometer reading, and body panels) before starting or finishing the rental.
              </p>

              {/* Photos Grid */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                {uploadedUrls.map((url, i) => (
                  <div key={i} className="relative rounded-lg overflow-hidden border border-slate-100 aspect-video">
                    <img src={url} alt={`Simulated condition ${i}`} className="w-full h-full object-cover" />
                    <div className="absolute top-1.5 right-1.5 bg-slate-900/80 rounded-full p-0.5 text-white">
                      <Check className="w-3 h-3 text-blue-400" />
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-blue-50/50 p-4 rounded-lg border border-blue-100 text-xs text-blue-800">
                <p className="font-bold">✓ Automated Metadata Attachment</p>
                <p className="text-[10px] mt-0.5">Odometer log, GPS coordinates, and timestamp (2026-06-26) are automatically saved into the secure DriveLink booking ledger.</p>
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  id="btn-cancel-upload"
                  onClick={() => { setUploadingBookingId(null); setUploadStage(null); }}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  id="btn-save-upload"
                  onClick={saveUploadedPhotos}
                  className="px-4 py-1.5 text-xs font-extrabold bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-sm"
                >
                  Confirm Upload
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
