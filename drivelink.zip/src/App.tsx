/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Car, 
  User, 
  ShieldCheck, 
  HelpCircle, 
  MapPin, 
  Compass, 
  Sparkles, 
  Lock,
  MessageSquare,
  Globe,
  Info,
  Calendar,
  Layers,
  X
} from 'lucide-react';
import { SAMPLE_VEHICLES } from './data';
import { Vehicle, BookingRequest } from './types';
import CustomerPortal from './components/CustomerPortal';
import OwnerPortal from './components/OwnerPortal';
import AdminPortal from './components/AdminPortal';

export default function App() {
  // Global States
  const [vehicles, setVehicles] = useState<Vehicle[]>(SAMPLE_VEHICLES);
  const [role, setRole] = useState<'customer' | 'owner' | 'admin'>('customer');
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Initial Seed Bookings
  const [bookings, setBookings] = useState<BookingRequest[]>([
    {
      id: 'b_9812',
      vehicleId: 'v_3',
      vehicleTitle: 'Toyota KDH Super Grand Cabin (With Driver)',
      vehicleImage: 'https://images.unsplash.com/photo-1527786356703-4b100091cd2c?auto=format&fit=crop&q=80&w=800',
      vehiclePrice: 60,
      customerName: 'The Tremblay Family',
      customerEmail: 'tremblay.tours@gmail.com',
      customerPhone: '+1 415 555 2671',
      customerCountry: 'Canada',
      startDate: '2026-06-01',
      endDate: '2026-06-04',
      rentalType: 'with-driver',
      pickupLocation: 'Bandaranaike Intl Airport (CMB)',
      returnLocation: 'Ella',
      totalDays: 3,
      totalPrice: 180,
      status: 'completed',
      createdAt: '5/28/2026',
      notes: 'Need standard infant child-seats if possible.',
      pickupPhotos: [
        'https://images.unsplash.com/photo-1527786356703-4b100091cd2c?auto=format&fit=crop&q=80&w=400'
      ],
      returnPhotos: [
        'https://images.unsplash.com/photo-1527786356703-4b100091cd2c?auto=format&fit=crop&q=80&w=400'
      ]
    },
    {
      id: 'b_7211',
      vehicleId: 'v_1',
      vehicleTitle: 'Toyota Prius Hybrid (Eco-Luxury)',
      vehicleImage: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=800',
      vehiclePrice: 30,
      customerName: 'Alex Thorne',
      customerEmail: 'alex.t@outlook.com',
      customerPhone: '+44 7911 888222',
      customerCountry: 'United Kingdom',
      startDate: '2026-06-25',
      endDate: '2026-06-28',
      rentalType: 'self-drive',
      pickupLocation: 'Colombo',
      returnLocation: 'Colombo',
      totalDays: 3,
      totalPrice: 90,
      status: 'approved_by_owner',
      createdAt: '6/24/2026',
      notes: 'Visiting Sigiriya and Hikkaduwa for beaches.'
    }
  ]);

  // Handlers
  const handleAddBooking = (newBooking: BookingRequest) => {
    setBookings(prev => [newBooking, ...prev]);
  };

  const handleUpdateBookingStatus = (bookingId: string, status: BookingRequest['status']) => {
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status } : b));
  };

  const handleUploadPhotos = (bookingId: string, stage: 'pickup' | 'return', photos: string[]) => {
    setBookings(prev => prev.map(b => {
      if (b.id === bookingId) {
        return stage === 'pickup' 
          ? { ...b, pickupPhotos: photos } 
          : { ...b, returnPhotos: photos };
      }
      return b;
    }));
  };

  const handleAddVehicle = (newVehicle: Vehicle) => {
    setVehicles(prev => [newVehicle, ...prev]);
  };

  const handleDeleteVehicle = (vehicleId: string) => {
    setVehicles(prev => prev.filter(v => v.id !== vehicleId));
  };

  const handleApproveVehicle = (vehicleId: string) => {
    setVehicles(prev => prev.map(v => v.id === vehicleId ? { ...v, isApproved: true, documentStatus: 'verified' } : v));
  };

  const handleRejectVehicle = (vehicleId: string) => {
    setVehicles(prev => prev.map(v => v.id === vehicleId ? { ...v, isApproved: false, documentStatus: 'rejected' } : v));
  };

  const handleVerifyBooking = (bookingId: string) => {
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: 'verified' } : b));
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      {showLoginModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden border border-slate-200">
            <div className="p-6 space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-extrabold text-slate-900">Sign In</h2>
                <button onClick={() => setShowLoginModal(false)} className="text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 p-1.5 rounded-full transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                <button 
                  onClick={() => { setRole('owner'); setShowLoginModal(false); }}
                  className="w-full flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50 transition-all text-left group"
                >
                  <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">Vehicle Owner</p>
                    <p className="text-xs text-slate-500 font-medium">Manage listings & bookings</p>
                  </div>
                </button>
                <button 
                  onClick={() => { setRole('admin'); setShowLoginModal(false); }}
                  className="w-full flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all text-left group"
                >
                  <div className="w-10 h-10 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">Platform Admin</p>
                    <p className="text-xs text-slate-500 font-medium">Verify licenses & vehicles</p>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Luxury Header */}
      <header className="sticky top-0 bg-white/85 backdrop-blur-md border-b border-slate-200 py-4 px-4 md:px-8 z-30 shadow-sm flex items-center justify-between">
        {/* Brand Logo & Slogan */}
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/10">
            <Car className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="font-extrabold text-lg text-slate-900 tracking-tight">DriveLink</span>
              <span className="text-[10px] font-extrabold uppercase bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">Beta</span>
            </div>
            <p className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase">Sri Lanka Vehicle Marketplace</p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-8">
          <button onClick={() => setRole('customer')} className={`text-sm font-bold transition-colors ${role === 'customer' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'}`}>Explore Vehicles</button>
          <button className="text-sm font-bold text-slate-500 hover:text-slate-800 transition-colors">Airport Transfers</button>
          <button className="text-sm font-bold text-slate-500 hover:text-slate-800 transition-colors">Tourist Permits</button>
          <button className="text-sm font-bold text-slate-500 hover:text-slate-800 transition-colors">Help</button>
        </nav>

        {role === 'customer' ? (
          <div className="flex items-center gap-4">
            <button onClick={() => setShowLoginModal(true)} className="px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Log In</button>
            <button onClick={() => { setRole('owner'); }} className="px-4 py-2.5 text-xs font-extrabold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" /> List Your Vehicle
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-4">
             <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
               {role === 'owner' ? <User className="w-3.5 h-3.5 text-blue-600" /> : <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />}
               Logged in as {role.charAt(0).toUpperCase() + role.slice(1)}
             </span>
             <button onClick={() => setRole('customer')} className="px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Log Out</button>
          </div>
        )}
      </header>

      {/* Main Container Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8">
        {role === 'customer' && (
          <CustomerPortal 
            vehicles={vehicles}
            bookings={bookings}
            onAddBooking={handleAddBooking}
            onUpdateBookingStatus={handleUpdateBookingStatus}
            onUploadPhotos={handleUploadPhotos}
          />
        )}

        {role === 'owner' && (
          <OwnerPortal
            vehicles={vehicles}
            bookings={bookings}
            onAddVehicle={handleAddVehicle}
            onUpdateBookingStatus={handleUpdateBookingStatus}
            onDeleteVehicle={handleDeleteVehicle}
          />
        )}

        {role === 'admin' && (
          <AdminPortal
            vehicles={vehicles}
            bookings={bookings}
            onApproveVehicle={handleApproveVehicle}
            onVerifyBooking={handleVerifyBooking}
            onRejectVehicle={handleRejectVehicle}
          />
        )}
      </main>

      {/* Aesthetic High-Contrast Footer */}
      <footer className="bg-slate-950 text-white border-t border-slate-900 py-12 px-4 md:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 text-xs text-slate-400">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
                DL
              </div>
              <span className="font-extrabold text-base text-white tracking-tight">DriveLink</span>
            </div>
            <p className="leading-relaxed">
              Sri Lanka's premier vehicle rental and tourist guiding network. Free launch model supporting cars, bikes, vans, with-driver tours and airport pick-ups.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase tracking-wider">Early Launch Verticals</h4>
            <ul className="space-y-1.5 font-medium">
              <li>• Self-Drive Sri Lanka Licensing Guide</li>
              <li>• Colombo Airport Transfer Packages</li>
              <li>• Kandy & Ella Mountain Cruiser Fleet</li>
              <li>• Mirissa Surf Scooters & Classic Bikes</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase tracking-wider">Verify & Onboard</h4>
            <ul className="space-y-1.5 font-medium">
              <li>• List Your Vehicle (0% Platform Fee)</li>
              <li>• Owner Document CR Verification</li>
              <li>• Driver Permit Validation Standards</li>
              <li>• Guest Licensing Requirements</li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider">DriveLink Support</h4>
            <p className="leading-relaxed">
              Need assistance with international license conversions or vehicle handovers?
            </p>
            <p className="font-extrabold text-blue-400 flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4" /> WhatsApp Support: +94 77 123 4567
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto border-t border-slate-900 mt-10 pt-6 flex flex-col md:flex-row items-center justify-between text-[11px] text-slate-600 font-bold">
          <p>© 2026 DriveLink Sri Lanka. Operating with Zero Platform Fees to capture first-phase market supply.</p>
          <div className="flex gap-4 mt-2 md:mt-0">
            <a href="#" className="hover:text-slate-400">Terms of Service</a>
            <a href="#" className="hover:text-slate-400">Privacy Policy</a>
            <a href="#" className="hover:text-slate-400">Sri Lanka Tourism Board Partner</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
