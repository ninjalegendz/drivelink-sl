/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type VehicleType = 'car' | 'van' | 'bike' | 'suv' | 'tuktuk';

export interface Vehicle {
  id: string;
  title: string;
  type: VehicleType;
  brand: string;
  model: string;
  year: number;
  image: string;
  pricePerDayLKR: number;
  pricePerDayUSD: number;
  transmission: 'automatic' | 'manual' | 'not-applicable';
  fuelType: 'petrol' | 'diesel' | 'hybrid' | 'electric';
  seats: number;
  luggage: number;
  location: string;
  isSelfDrive: boolean;
  isWithDriver: boolean;
  isAirportPickup: boolean;
  depositLKR: number;
  depositUSD: number;
  mileageLimit: string;
  extraMileageCharge: number;
  rules: string[];
  ownerId: string;
  ownerName: string;
  ownerPhone: string;
  ownerAvatar: string;
  ownerRating: number;
  ownerResponseTime: string;
  badges: string[];
  reviewsCount: number;
  isApproved: boolean;
  documentStatus: 'pending' | 'verified' | 'rejected';
}

export interface BookingRequest {
  id: string;
  vehicleId: string;
  vehicleTitle: string;
  vehicleImage: string;
  vehiclePrice: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerCountry: string;
  startDate: string;
  endDate: string;
  rentalType: 'self-drive' | 'with-driver' | 'airport-pickup';
  pickupLocation: string;
  returnLocation: string;
  totalDays: number;
  totalPrice: number;
  status: 'pending' | 'verified' | 'approved_by_owner' | 'completed' | 'rejected';
  createdAt: string;
  notes?: string;
  pickupPhotos?: string[];
  returnPhotos?: string[];
}

export interface Owner {
  id: string;
  name: string;
  email: string;
  phone: string;
  businessName?: string;
  location: string;
  isVerified: boolean;
  joinedDate: string;
  listingsCount: number;
  completedBookings: number;
}

export interface Review {
  id: string;
  vehicleId: string;
  authorName: string;
  authorCountry: string;
  rating: number;
  date: string;
  comment: string;
}
